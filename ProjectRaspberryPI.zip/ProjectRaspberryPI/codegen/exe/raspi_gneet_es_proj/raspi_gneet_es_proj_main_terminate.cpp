/* Include Files */
#include "raspi_gneet_es_proj_terminate.h"

/* Function Definition */
void main_terminate(void)
{
    /* Call the entry-point function. */
    raspi_gneet_es_proj_terminate();
}

/*
 * File trailer for main_terminate
 *
 * [EOF]
 */
