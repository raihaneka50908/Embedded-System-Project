clc;clear;close all

load MyNet_Result.mat
cam=